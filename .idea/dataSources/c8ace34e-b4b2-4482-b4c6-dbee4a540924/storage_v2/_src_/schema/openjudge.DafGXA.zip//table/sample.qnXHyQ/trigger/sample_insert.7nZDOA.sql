create definer = root@localhost trigger sample_insert
    before insert
    on sample
    for each row
begin
    set new.GMT_MODIFIED = now(), new.GMT_CREATED = now();
end;

