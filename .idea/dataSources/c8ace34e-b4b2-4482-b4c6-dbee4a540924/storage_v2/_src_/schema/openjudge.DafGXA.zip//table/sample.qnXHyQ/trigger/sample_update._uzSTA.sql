create definer = root@localhost trigger sample_update
    before update
    on sample
    for each row
begin
    set new.GMT_MODIFIED = now();
end;

