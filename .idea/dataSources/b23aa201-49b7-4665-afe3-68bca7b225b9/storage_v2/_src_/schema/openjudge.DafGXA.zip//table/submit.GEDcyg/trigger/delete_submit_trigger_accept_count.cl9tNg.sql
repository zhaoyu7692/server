create definer = root@localhost trigger delete_submit_trigger_accept_count
    after delete
    on submit
    for each row
BEGIN
    DECLARE total_count, accept_count INT DEFAULT 0;
    SELECT COUNT(1) INTO total_count FROM submit WHERE CID = OLD.CID AND `INDEX` = OLD.`INDEX`;
    SELECT COUNT(1) INTO accept_count FROM submit WHERE STATUS = 11 AND CID = OLD.CID AND `INDEX` = OLD.`INDEX`;

    UPDATE contest_problem_mapping
    SET ACCEPT = accept_count,
        TOTAL  = total_count
    WHERE CID = OLD.CID
      AND `INDEX` = OLD.`INDEX`;
END;

