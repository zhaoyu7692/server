create definer = root@localhost trigger submit_update
    before update
    on submit
    for each row
BEGIN
    SET NEW.GMT_MODIFIED = NOW();
end;

