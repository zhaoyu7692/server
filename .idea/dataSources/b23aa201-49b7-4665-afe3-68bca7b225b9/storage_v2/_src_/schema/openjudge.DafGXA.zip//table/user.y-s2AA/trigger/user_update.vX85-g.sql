create definer = root@localhost trigger user_update
    before update
    on user
    for each row
BEGIN
    SET NEW.LAST_MODIFIED = NOW(), NEW.GMT_MODIFIED = NOW();
end;

