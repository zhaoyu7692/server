create definer = root@localhost trigger contest_insert
    before insert
    on contest
    for each row
BEGIN
    SET NEW.GMT_MODIFIED = NOW(), NEW.GMT_CREATED = NOW();
end;

