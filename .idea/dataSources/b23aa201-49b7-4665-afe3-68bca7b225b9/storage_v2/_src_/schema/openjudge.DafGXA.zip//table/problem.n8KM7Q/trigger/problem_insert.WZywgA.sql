create definer = root@localhost trigger problem_insert
    before insert
    on problem
    for each row
BEGIN
    SET NEW.GMT_MODIFIED = NOW(), NEW.GMT_CREATED = NOW();
end;

