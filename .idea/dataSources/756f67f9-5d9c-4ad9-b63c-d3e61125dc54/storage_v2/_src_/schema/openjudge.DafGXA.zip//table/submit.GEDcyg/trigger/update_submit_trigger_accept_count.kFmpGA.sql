create definer = root@localhost trigger update_submit_trigger_accept_count
    after update
    on submit
    for each row
BEGIN
    DECLARE total_count, accept_count INT DEFAULT 0;
    SELECT COUNT(1) INTO total_count FROM submit WHERE CID = NEW.CID AND `INDEX` = NEW.`INDEX`;
    SELECT COUNT(1) INTO accept_count FROM submit WHERE STATUS = 11 AND CID = NEW.CID AND `INDEX` = NEW.`INDEX`;

    UPDATE contest_problem_mapping
    SET ACCEPT = accept_count,
        TOTAL  = total_count
    WHERE CID = NEW.CID
      AND `INDEX` = NEW.`INDEX`;
END;

