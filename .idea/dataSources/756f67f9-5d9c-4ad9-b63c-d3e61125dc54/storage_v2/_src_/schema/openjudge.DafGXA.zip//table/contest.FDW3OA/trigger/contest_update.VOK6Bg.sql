create definer = root@localhost trigger contest_update
    before update
    on contest
    for each row
BEGIN
    SET NEW.GMT_MODIFIED = NOW();
end;

