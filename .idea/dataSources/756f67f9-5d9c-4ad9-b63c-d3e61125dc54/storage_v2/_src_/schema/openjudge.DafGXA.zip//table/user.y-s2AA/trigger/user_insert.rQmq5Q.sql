create definer = root@localhost trigger user_insert
    before insert
    on user
    for each row
BEGIN
    SET NEW.LAST_AUTHORITY = NOW(), NEW.GMT_MODIFIED = NOW(), NEW.GMT_CREATED = NOW();
end;

