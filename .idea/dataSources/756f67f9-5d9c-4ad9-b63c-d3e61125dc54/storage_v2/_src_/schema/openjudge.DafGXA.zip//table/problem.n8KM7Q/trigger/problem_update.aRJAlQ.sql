create definer = root@localhost trigger problem_update
    before update
    on problem
    for each row
BEGIN
    SET NEW.GMT_MODIFIED = NOW();
end;

